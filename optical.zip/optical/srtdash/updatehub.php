<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>optical</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
		<script type="text/javascript">
     function initGeolocation()
     {
        if( navigator.geolocation )
        {
           // Call getCurrentPosition with success and failure callbacks
           navigator.geolocation.getCurrentPosition( success, fail );
        }
        else
        {
           alert("Sorry, your browser does not support geolocation services.");
        }
     }

     function success(position)
     {

         document.getElementById('long').value = position.coords.longitude;
         document.getElementById('lat').value = position.coords.latitude;
     }

     function fail()
     {
        // Could not obtain location
     }

   </script>
</head>

<body onLoad="initGeolocation();">
<?php
  error_reporting(0);
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['did'])){
		$longi = stripslashes($_REQUEST['longi']); // removes backslashes
		$longi = mysqli_real_escape_string($con,$longi); //escapes special characters in a string
		$lat = stripslashes($_REQUEST['lat']);
		$lat = mysqli_real_escape_string($con,$lat);

		$did = stripslashes($_REQUEST['did']);
		$did = mysqli_real_escape_string($con,$did);
		$dtype = stripslashes($_REQUEST['dtype']);
		$dtype = mysqli_real_escape_string($con,$dtype);
		
		$area = stripslashes($_REQUEST['area']);
		$area = mysqli_real_escape_string($con,$area);
		$img = stripslashes($_REQUEST['img']);
		$img = mysqli_real_escape_string($con,$img);
		
		

		
		 $query = mysqli_query($con, "SELECT * FROM  deviceinfo WHERE did = '".$did. "'");
  if(mysqli_num_rows(  $query) > 0){
   echo "<div class='form'><h3>!!!!!!!!!!! Device  already exist please use other.</h3><br/>Click here to try again <a href='updatehub.php'>Update Device</a></div>";
}
else{
 $query = "INSERT into `deviceinfo` (dlong,dlat,did,dtype,img,area) VALUES ('$longi', '$lat','$did','$dtype','$img','$area')";
        $result = mysqli_query($con,$query);
		

}
        if($result){
   
			
			?><script type="text/javascript">
            window.alert("Device info Successfully  Updated");
            window.location="updatehub.php";
            </script><?php
			
			
           }
    }else{
?>
    <div id="preloader">
        <div class="loader"></div>
    </div>
   
    <div class="page-container">
       
        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href="index.html"><h1>Cellular</h1></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
       <ul class="metismenu" id="menu">
                            <li class="active">
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>dashboard</span></a>
                                <ul class="collapse">
                                    <li class="active"><a href="dashboard.php">viewworkers</a></li>
                                    
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Workers
                                    </span></a>
                                <ul class="collapse">

                                    <li><a href="viewactive.php">View Active Workers</a></li>
									<li><a href="problem.php">Send Router/Hub Problem Statement</a></li>
									<li><a href="problemofc.php">Send OFC Problem Statement</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-pie-chart"></i><span>Update Device</span></a>
                                <ul class="collapse">
                                    <li><a href="updateofc.php">OFC-LINE</a></li>
                                    <li><a href="updatehub.php">HUB/ROUTER</a></li>
                                    
                                </ul>
                            </li>
							 <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-palette"></i><span>View Device</span></a>
                                <ul class="collapse">
                                    <li><a href="viewofc.php">OFC-LINE</a></li>
                                    <li><a href="viewhub.php">HUB/ROUTER</a></li>
                                    
                                </ul>
                            </li>
                           
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-slice"></i><span>Service Details</span></a>
                                <ul class="collapse">
                                    <li><a href="fontawesome.html">OFC-LINE</a></li>
                                    <li><a href="themify.html">HUB/ROUTER</a></li>
                                </ul>
                            </li>
							
                        
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Dashboard</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="index.html">Home</a></li>
                                <li><span>Form</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 clearfix">
                        <div class="user-profile pull-right">
                            <img class="avatar user-thumb" src="assets/images/author/avatar.png" alt="avatar">
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown"><?php error_reporting(0); echo $_SESSION['username']; ?> <i class="fa fa-angle-down"></i></h4>
                            <div class="dropdown-menu">
								<div class="dropdown-menu">
                                <a class="dropdown-item" href="#">Message</a>
                                <a class="dropdown-item" href="#">Settings</a>
                                <a class="dropdown-item" href="#">Log Out</a>
								</div>
                                
                                <a class="dropdown-item" href="logout.php">Log Out</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
                <div class="row">
                    <div class="col-lg-12 col-ml-5">
                        <div class="row">
                            <!-- Textual inputs start -->
                         
                            <!-- Disabled forms end -->
                            <!-- Server side start -->
                            <div class="col-12">
                                <div class="card mt-5">
                                    <div class="card-body">
                                        <h4 class="header-title">Update Router / Hub Placed Location</h4>
                                        <form action="" method="post" >
                                            <div class="form-row">
                                                <div class="col-md-4 mb-3">
                                                    <label for="validationCustom01">Longtide</label>
                                                    <input type="text" name="longi" class="form-control" ID="long"  required="">
                                                   
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="validationCustom02">Latitude</label>
                                                    <input type="text" name="lat" class="form-control" ID="lat" required="">
                                                    
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="validationCustomUsername">Select Device Type</label>
                                                    <div class="input-group">
                                                       
														<select class="form-control" name="dtype">
														<option  class="form-control" value="null">Select Device Type</option>
														<option value="Router">Router</option>
														<option value="Hub">Hub</option>
														</select>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="col-md-4 mb-3">
                                                    <label for="validationCustomUsername">Select Region</label>
                                                    <div class="input-group">
                                                       
														<select name="area" class="form-control" >
						   <option value="NULL">---SELECT ZONE--</OPTION>
						   <option value="MYSURU-ZONE1">MYSURU-ZONE1</OPTION>
						   <option value="MYSURU-ZONE2">MYSURU-ZONE2</OPTION>
						    <option value="MYSURU-ZONE3">MYSURU-ZONE3</OPTION>
						   <option value="MYSURU-ZONE4">MYSURU-ZONE4</OPTION>
						    <option value="MYSURU-ZONE5">MYSURU-ZONE5</OPTION>
						   <option value="MYSURU-ZONE6">MYSURU-ZONE6</OPTION></SELECT>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-3 mb-3">
                                                    <label for="validationCustom04">Hint Image</label>
                                                    <input type="file" class="form-control" name="img" required="">
                                                    <div class="invalid-feedback">
                                                        Please provide a image
                                                    </div>
                                                </div>
                                                <div class="col-md-3 mb-3">
                                                    <label for="validationCustom05">Device ID</label>
                                                    <input type="text" class="form-control" name="did" placeholder="Device ID" required="">
                                                    <div class="invalid-feedback">
                                                        Please provide a valid zip.
                                                    </div>
                                                </div>
                                            </div>
                                         
                                            <button class="btn btn-primary" type="submit">Submit form</button>
                                        </form>
                                    </div>
                                </div>
									<?php } ?>
                            </div>
                            <!-- Server side end -->
                            <!-- Input Group start -->
                            
                            <!-- Custom file input end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
            <div class="footer-area">
                <p>© Copyright 2018. All right reserved. Template by <a href="https://colorlib.com/wp/">Colorlib</a>.</p>
            </div>
        </footer>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    <!-- offset area start -->
    
    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>
