		<?php

require('db.php');
// If form submitted, insert values into the database.
if (isset($_REQUEST['username'])){
        // removes backslashes
	$username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($con,$username); 
	$email = stripslashes($_REQUEST['email']);
	$email = mysqli_real_escape_string($con,$email);
	
	

	
	$phone = stripslashes($_REQUEST['phone']);
	$phone = mysqli_real_escape_string($con,$phone);
	$area = stripslashes($_REQUEST['area']);
	$area = mysqli_real_escape_string($con,$area);
	$company = stripslashes($_REQUEST['company']);
	$company = mysqli_real_escape_string($con,$company);
	
	$status = stripslashes($_REQUEST['status']);
	$status = mysqli_real_escape_string($con,$status);
	
	$trn_date = date("Y-m-d H:i:s");
	
	$query ="UPDATE users SET email='$email',area='$area',status='$status',phone='$phone' WHERE username='$username'";

        
        $result = mysqli_query($con,$query);
        if($result){
           echo"Record inserted";?>
		<script type="text/javascript">
            window.alert("successfully Updated");
            window.location="updatestatus.php";
            </script>
			<?php 
        }
    }
?>