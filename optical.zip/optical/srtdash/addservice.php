<?php


include("auth.php");  ?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>optcal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
<!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href=""><h1><?php echo $_SESSION['username']; ?></h1></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                                        <ul class="metismenu" id="menu">
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>dashboard</span></a>
                                <ul class="collapse">
                                    <li><a href="updatestatus.php">Updatestatus</a></li>

                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>View Problem Statement
                                    </span></a>
                                <ul class="collapse">
                                    <li><a href="viewofcproblem.php">OFC </a></li>
                                    <li><a href="viewhubproblem.php">Router / Hub</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-pie-chart"></i><span>Add Service Details</span></a>
                                <ul class="collapse">
                                    <li><a href="addservice.php">Add Service Info</a></li>
									 <li><a href="addservice.php">View Previous Service Info</a></li>
                                   

                                </ul>
                            </li>
                          
                            
                           
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <div class="header-area">
                <div class="row align-items-center">
                    <!-- nav and search button -->
                
                    <!-- profile info & task notification -->
                    <div class="col-md-6 col-sm-4 clearfix">
                        
                    </div>
                </div>
            </div>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Dashboard</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="home.html">Home</a></li>
                                <li><span>Form</span></li>
                            </ul>
                        </div>
                    </div>
                   <div class="col-sm-6 clearfix">
                        <div class="user-profile pull-right">
                            <img class="avatar user-thumb" src="assets/images/author/avatar.png" alt="avatar">
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown"><?php error_reporting(0); echo $_SESSION['username']; ?> <i class="fa fa-angle-down"></i></h4>
                            <div class="dropdown-menu">
                                
                                <a class="dropdown-item" href="logout.php">Log Out</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
                <div class="row">
                    <div class="col-lg-12 col-ml-5">
                        <div class="row">
                            <!-- Textual inputs start -->
            
                            <!-- basic form start -->
                            <div class="col-12 mt-5">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Basic form</h4>
                                        <form action="servicedb.php" method="post"><label for="exampleInputName1">Worker ID</label>
                                            <div class="form-gp">
                           
                            <input type="text" name="p1" value="<?php  echo $_SESSION['username']; ?>" required id="exampleInputName1">
                            <i class="ti-user"></i>
                        </div>      <label for="exampleInputName1">Repaired Device ID </label>
						<div class="form-gp">
                      
                            <input type="text" name="p2"required name="did"  >
                            <i class="ti-user"></i>
                        </div> 
	<div class="form-gp">
                            
                           <select name="p3" class="form-control" >
						   <option value="NULL">---SELECT ZONE--</OPTION>
						   	   <option value="BANGLORE-ZONE1">BANGLORE-ZONE1</OPTION>
						   <option value="BANGLORE-ZONE2">BANGLORE-ZONE2</OPTION>
						    <option value="BANGLORE-ZONE3">BANGLORE-ZONE3</OPTION>
						   <option value="BANGLORE-ZONE4">BANGLORE-ZONE4</OPTION>
						    <option value="BANGLORE-ZONE5">BANGLORE-ZONE5</OPTION>
						   <option value="BANGLORE-ZONE6">BANGLORE-ZONE6</OPTION></SELECT>
                        </div>
						<div class="form-gp">
                            
                           <select name="p4"  class="form-control">
						   <option value="NULL">---SELECT DEVICE--</OPTION>
						   <option value="Ofc">OFC</OPTION>
						   <option value="Router">ROUTER</OPTION>
						    <option value="Hub">HUB</OPTION>
						  </SELECT>
                        </div>

						<label for="exampleInputName1">Repaired Statement </label>
						<div class="form-gp">
                          
                            <input type="text" name="p5"  required >
                            <i class="ti-user"></i>
                        </div> <label for="exampleInputName1">Total Expence Amount</label>
							<div class="form-gp">
                           
                            <input type="text" name="p6"Placeholder="Rs" required >
                            <i class="ti-user"></i>
                        </div>
						
					
						<div class="form-gp">
                            
                           <select name="p7" class="form-control">
						   <option value="NULL">---SELECT SERVICE--</OPTION>
						   <option value="STARTED">STARTED</OPTION>
						   <option value="ENGAGE">ENGAGE</OPTION>
						    <option value="FINISHED">FINISHED</OPTION>
						  </SELECT>
                        </div>
						<div class="form-gp">
                            
                           <select name="p8" class="form-control">
						   <option value="NULL">---SELECT PROBLEM TYPE--</OPTION>
						   <option value="SIGNAL">SIGNAL</OPTION>
						   <option value="NO_SERVICE">NO SERVICE</OPTION>
						    <option value="HARDWARE">HARDWARE</OPTION>
							<option value="CONNECTION">CONNECTION</OPTION>
						   <option value="OTHER">OTHER</OPTION>
						    
						  </SELECT>
                        </div>
						<label for="exampleInputName1">ENTER COMPLETE PROBLEM STATEMENT</label>
							<div class="form-gp">
                           
                            <textarea name="p9" class="form-control"> </textarea>
                            <i class="ti-user"></i>
                        </div>
                                            <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">UPDATE SERVICE DETAILS</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- basic form end -->
                            <!-- basic form start -->
                            
                            <!-- Custom file input end -->
                        </div>
                    </div>
                </div>
				
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
            <div class="footer-area">
                <p>© OPTICAL  </p>
            </div>
        </footer>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    <!-- offset area start -->

    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>
