<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>optcal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href=""><h1>Cellular</h1></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                               <ul class="metismenu" id="menu">
                          
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Workers
                                    </span></a>
                               <ul class="collapse">

                                    <li><a href="viewactive.php">View Active Workers</a></li>
									<li><a href="problem.php">Send Router/Hub Problem Statement</a></li>
									<li><a href="problemofc.php">Send OFC Problem Statement</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-pie-chart"></i><span>Update Device</span></a>
                                <ul class="collapse">
                                    <li><a href="updateofc.php">OFC-LINE</a></li>
                                    <li><a href="updatehub.php">HUB/ROUTER</a></li>
                                    
                                </ul>
                            </li>
							 <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-palette"></i><span>View Device</span></a>
                                <ul class="collapse">
                                    <li><a href="viewofc.php">OFC-LINE</a></li>
                                    <li><a href="viewhub.php">HUB/ROUTER</a></li>
                                    
                                </ul>
                            </li>
                           
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-slice"></i><span>Service Details</span></a>
                                <ul class="collapse">
                                    <li><a href="viewrepair.php">Service Info</a></li>
                                   
                                </ul>
                            </li>
							
                        
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Dashboard</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="home.html">Home</a></li>
                                <li><span>Form</span></li>
                            </ul>
                        </div>
                    </div>
                     <div class="col-sm-6 clearfix">
                        <div class="user-profile pull-right">
                            <img class="avatar user-thumb" src="assets/images/author/avatar.png" alt="avatar">
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown"><?php error_reporting(0); echo $_SESSION['username']; ?> <i class="fa fa-angle-down"></i></h4>
                            <div class="dropdown-menu">
								<div class="dropdown-menu">
                                <a class="dropdown-item" href="#">Message</a>
                                <a class="dropdown-item" href="#">Settings</a>
                                <a class="dropdown-item" href="#">Log Out</a>
								</div>
                                
                                <a class="dropdown-item" href="logout.php">Log Out</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
                <div class="row">
                    <div class="col-lg-6 col-ml-12">
                        <div class="row">
                            <!-- Textual inputs start -->
                         
                            <!-- Disabled forms end -->
                            <!-- Server side start -->
							<div class="col-12">
                                <div class="card mt-5">
                                    <div class="card-body">
                                        <h4 class="header-title">Update Router / Hub Placed Location</h4>
                                        <form class="needs-validation"  action="" method="post">
                                            <div class="form-row">
                                                <div class="col-md-4 mb-3">
                                                      <select name="area" class="form-control" >
						   <option value="NULL">---SELECT ZONE--</OPTION>
						   	   <option value="BANGLORE-ZONE1">BANGLORE-ZONE1</OPTION>
						   <option value="BANGLORE-ZONE2">BANGLORE-ZONE2</OPTION>
						    <option value="BANGLORE-ZONE3">BANGLORE-ZONE3</OPTION>
						   <option value="BANGLORE-ZONE4">BANGLORE-ZONE4</OPTION>
						    <option value="BANGLORE-ZONE5">BANGLORE-ZONE5</OPTION>
						   <option value="BANGLORE-ZONE6">BANGLORE-ZONE6</OPTION></SELECT>
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <select name="status" class="form-control">
						   <option value="NULL">---SELECT STATUS--</OPTION>
						   <option value="ACTIVE">ACTIVE</OPTION>
						   <option value="ENGAGE_IN_WORK">ENGAGE_IN_WORK</OPTION>
						    <option value="NOT-ACTIVE">NOT-ACTIVE</OPTION>
						  </SELECT>
                                                </div>
                                               
                                            </div>
										
                                          
                                          
                                             <input class="btn btn-success" name="submit" type="submit"  value="Search" />
                                        </form>
                                    </div>
                                </div>
                            </div>
							<?php
 error_reporting(0);
	  $a=$_POST['area'];
	    $b=$_POST['status'];
	 $query="SELECT * from users where area='$a' and status='$b' ";
$mysql_hostname = "localhost";
$mysql_user     = "root";
$mysql_password = "";
$mysql_database = "optical";
$con = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password,$mysql_database);
if(mysqli_connect_errno())
{
	echo"failed to connect to MysQl: ". mysqli_connect_error();
}
$result = mysqli_query($con,$query); // selecting where data through mysql_query()
?>
                            <div class="col-12">
                                <div class="card mt-5">
								<?php while($data = mysqli_fetch_array($result))
{?>
                                    <div class="card-body">
                                        <h4 class="header-title">ACTIVE USERS</h4>
                                        <form class="needs-validation" novalidate="">
										
										<h4 class="header-title"><?php echo $data['username']; ?></h4>
                                            <div class="form-row">
                                                <div class="col-md-4 mb-3">
                                                    <label for="validationCustom02">NAME</label>
                                                    <input type="text" class="form-control" id="validationCustom01" value="<?php echo $data['name']; ?>" readonly>
                                                   
                                                </div>
                                                <div class="col-md-4 mb-3">
                                                    <label for="validationCustom02">PHONE</label>
                                                    <input type="text" class="form-control" id="validationCustom02" value="<?php echo $data['phone']; ?>" readonly>
                                                    
                                                </div>
                                               
                                            </div>
											
                                            
                                        </form>
                                    </div>
									<?php } ?>
                                </div>
                            </div>
                            <!-- Server side end -->
                            <!-- Input Group start -->
                            
                            <!-- Custom file input end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
           
        </footer>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    <!-- offset area start -->
    
    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>
