<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Optical</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
<?php
  error_reporting(0);
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['username'])){
		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
		$company = stripslashes($_REQUEST['company']);
		$company = mysqli_real_escape_string($con,$company);
		$email = stripslashes($_REQUEST['email']);
		$email = mysqli_real_escape_string($con,$email);
		$name = stripslashes($_REQUEST['name']);
		$name = mysqli_real_escape_string($con,$name);
		$area = stripslashes($_REQUEST['area']);
		$area = mysqli_real_escape_string($con,$area);
		$phone = stripslashes($_REQUEST['phone']);
		$phone = mysqli_real_escape_string($con,$phone);
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
$a=0;
		$trn_date = date("Y-m-d H:i:s");
		
		 $query = mysqli_query($con, "SELECT * FROM users WHERE username = '".$username. "'");
  if(mysqli_num_rows(  $query) > 0){
   echo "<div class='form'><h3>!!!!!!!!!!! user name already exist please user other.</h3><br/>Click here to try again <a href='register.php'>Register</a></div>";
}
else{
 $query = "INSERT into `users` (username,company,name,area,phone,email, password,  trn_date ,status) VALUES ('$username', '$company','$name','$area','$phone','$email','".md5($password)."',  '$trn_date','$a')";
        $result = mysqli_query($con,$query);
		

}
        if($result){
   ini_set("SMTP", "smtpout.secureserver.net");//confirm smtp
      $to = "$email";
      $subject = "Test mail";
      $message = "Hello! This is a simple email message.";
      $from = "mpsuresh77@gmail.com";
      $headers = "From: $from";
      mail($to,$subject,$message,$headers);
      	
		header("location: login.php");
		exit();
			
			
			
			
            echo "<div class='form'><h3>You are registered successfully.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
        }
    }else{
?>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- login area start -->
    <div class="login-area">
        <div class="container">
            <div class="login-box ptb--100">
                 <form name="registration" action="" method="post">
                    <div class="login-form-head">
                        <h4>Sign up</h4>
                        <p>Welcome To Cellular Routing Portal</p>
                    </div>
                    <div class="login-form-body">
                        <div class="form-gp">
                            <label for="exampleInputName1">Company Name</label>
                            <input type="text" name="company" required id="exampleInputName1">
                            <i class="ti-user"></i>
                        </div>
						<div class="form-gp">
                            <label for="exampleInputName1">Phone</label>
                            <input type="tel" maxlength=10 required name="phone" id="exampleInputName1">
                            <i class="ti-user"></i>
                        </div>
						<div class="form-gp">
                            <label for="exampleInputName1">Worker ID</label>
                            <input type="text" name="username"required id="exampleInputName1">
                            <i class="ti-user"></i>
                        </div>
							<div class="form-gp">
                            <label for="exampleInputName1">Full Name</label>
                            <input type="text" name="name" required id="exampleInputName1">
                            <i class="ti-user"></i>
                        </div>
                        <div class="form-gp">
                            <label for="exampleInputEmail1">Email address</label>
                            <input type="email" name="email" id="exampleInputEmail1" required>
                            <i class="ti-email"></i>
                        </div>
						<div class="form-gp">
                           <div class="form-gp">
                            
                           <select name="area" class="form-control">
						   <option value="NULL">---SELECT ZONE--</OPTION>
						   <option value="BANGLORE-ZONE1">BANGLORE-ZONE1</OPTION>
						   <option value="BANGLORE-ZONE2">BANGLORE-ZONE2</OPTION>
						    <option value="BANGLORE-ZONE3">BANGLORE-ZONE3</OPTION>
						   <option value="BANGLORE-ZONE4">BANGLORE-ZONE4</OPTION>
						    <option value="BANGLORE-ZONE5">BANGLORE-ZONE5</OPTION>
						   <option value="BANGLORE-ZONE6">BANGLORE-ZONE6</OPTION></SELECT>
                        </div>
                                 
                        </div>
                        <div class="form-gp">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" name="password" id="exampleInputPassword1"required>
                            <i class="ti-lock"></i>
                        </div>
                        <div class="form-gp">
                            <label for="exampleInputPassword2">Confirm Password</label>
                            <input type="password" id="exampleInputPassword2"required>
                            <i class="ti-lock"></i>
                        </div>
                        <div class="submit-btn-area">
                            <button id="form_submit" type="submit">Submit <i class="ti-arrow-right"></i></button>
                          
                        </div>
                        <div class="form-footer text-center mt-5">
                            <p class="text-muted">Don't have an account? <a href="login.php">Sign in</a></p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
		<?php } ?>
    </div>
    <!-- login area end -->

    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>