<?php 
$db="optical";
$user="root";
$pass="";
$server="localhost";
$a= $_POST['p1'];




$con=mysqli_connect($server,$user,$pass,$db);

if($con){
	
	$sql="delete from ofcinfo where ofcid='$a'";
	if($con->query($sql)===TRUE){
		echo"Record inserted";?>
		<script type="text/javascript">
            window.alert("Device deleted");
            window.location="viewofc.php";
            </script>
			<?php 
}else{
	echo"connection error";
}
}
?>